var test = localStorage.loggedin;
    if(test != "true"){
        window.location.replace("login.php");
}
var config = {
  apiKey: "AIzaSyD0CsnZgDBGSFBVrtZH0HRBbVQWk__txe0",
  authDomain: "ezbio-98be1.firebaseapp.com",
  databaseURL: "https://ezbio-98be1.firebaseio.com",
  storageBucket: "ezbio-98be1.appspot.com",
  messagingSenderId: "595946963410"
};
firebase.initializeApp(config);
$(document).ready(function () {
        firebase.database().ref('classes').orderByKey().once('value').then(function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
            var code =  childSnapshot.key;
            var section = childSnapshot.val().grp_name;
            var year = childSnapshot.val().grp_year;
            var gteacher = childSnapshot.val().grp_teacher;
            var gsubject = childSnapshot.val().grp_subject;
            var gstatus = childSnapshot.val().grp_status;
            var gcap = childSnapshot.val().grp_capacity;
            var gcreated = new Date(childSnapshot.val().grp_date_created).toLocaleString();
            var hey = "<a href = \"assessment.php?sec=" + CryptoJS.AES.encrypt(section, "Secret Passphrase") +"\">Members</a>";
            var currcount = 0;
            firebase.database().ref("classes/"+code+"/member").once('value').then(function(snapshot){
              currcount = snapshot.numChildren();
            }).then(function(){
              var cap = currcount + "/" + gcap;
              if(gteacher == localStorage.teacher && gstatus == "Active"){
                 $('#tbl_class').DataTable().row.add( [code, section, gsubject, year, cap, gcreated, gstatus, hey, "<a href = 'addnewclass.php?action=1&code="+code+"'>Edit</a> <a onclick = 'deactivate(\""+code+"\");'>Deactivate</a> <a onclick = 'deleteClass(\""+code+"\");'>Delete</a>"] ).draw();
              }else if(gteacher == localStorage.teacher && gstatus == "Inactive"){
                 $('#tbl_class').DataTable().row.add( [code, section, gsubject, year, cap, gcreated, gstatus, hey, "<a href = 'addnewclass.php?action=1&code="+code+"'>Edit</a><a onclick = 'activate(\""+code+"\");'>Activate</a> <a onclick = 'deleteClass(\""+code+"\");'>Delete</a>"] ).draw();
              }
            });
        });
    });
});
firebase.database().ref("classes").on('child_changed', function(){
  window.location.href = "classes.php";
});
function deactivate(code){
  var teacherkey = localStorage.memberkey;
  firebase.database().ref("classes/"+code).update({grp_status: "Inactive"});
  window.location.href = "classes.php";
}
function activate(code){
  var teacherkey = localStorage.memberkey;
  firebase.database().ref("classes/"+code).update({grp_status: "Active"});
  window.location.href = "classes.php";
}
function deleteClass(code){
  var conf = confirm("Delete this class?");
  if (conf == true){
    firebase.database().ref("classes/"+code).remove();
    window.location.href = "classes.php";
  }
}
function logout(){
    firebase.auth().signOut().then(function() {
      localStorage.clear();
      window.location.replace("login.php");
    }, function(error) {
      alert('Sign Out Error', error);
    });
}
