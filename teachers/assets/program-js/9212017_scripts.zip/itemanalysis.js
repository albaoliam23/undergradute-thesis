/*------------------------------------------------------
    Author : www.webthemez.com
    License: Commons Attribution 3.0
    http://creativecommons.org/licenses/by/3.0/
---------------------------------------------------------  */
var config = {
  apiKey: "AIzaSyD0CsnZgDBGSFBVrtZH0HRBbVQWk__txe0",
  authDomain: "ezbio-98be1.firebaseapp.com",
  databaseURL: "https://ezbio-98be1.firebaseio.com",
  storageBucket: "ezbio-98be1.appspot.com",
  messagingSenderId: "595946963410"
};
firebase.initializeApp(config);
var test = localStorage.loggedin;
  if(test != "true"){
      window.location.replace("welcomepage.php");
}
var member_count = 0;
$(document).ready(function () {
  countMembers();
  itemAnalysis();
});
function countMembers(){
  var gkeys = new Array();
  var s = CryptoJS.AES.decrypt(GetParameterValues("s"), "Secret Passphrase").toString(CryptoJS.enc.Utf8)
  firebase.database().ref("classes").orderByKey().once('value').then(function(snapshot){
    snapshot.forEach(function(childSnapshot){
      var gteacherkey = childSnapshot.val().grp_teacher_key;
      var gsubject = childSnapshot.val().grp_subject;
      if(gteacherkey == localStorage.memberkey && gsubject == s){
        gkeys.push(childSnapshot.key);
      }
    });
  }).then(function(){
    gkeys.forEach(function(canc){
      firebase.database().ref("classes/"+ canc +"/").child("member").once('value').then(function(snapshot){
        member_count = member_count + parseInt(snapshot.numChildren());
      });
    });
  });
}
function itemAnalysis(){
  var questions_array = new Array();
  var difficulty = new Array();
  var analysis = new Array();
  var loc = CryptoJS.AES.decrypt(GetParameterValues("subj"), "Secret Passphrase").toString(CryptoJS.enc.Utf8);
  firebase.database().ref(loc + "/quiz/questions").orderByKey().once('value').then(function(snapshot) {
    snapshot.forEach(function(childSnapshot){
      if(childSnapshot.key != "q_numofItems")
        questions_array.push(childSnapshot.val().q_question);
    });
  }).then(function(){
    firebase.database().ref(loc + "/quiz/item_analysis").orderByKey().once('value').then(function(snapshot) {
      snapshot.forEach(function(childSnapshot){
        childSnapshot.forEach(function(grandchildSnapshot){
          difficulty.push((grandchildSnapshot.numChildren() / member_count)*100);
        });
      });
    }).then(function(){
      for (var i = 0 ; i < questions_array.length ; ++i){
        parseFloat(difficulty[i]);
        analysis[questions_array[i]] = difficulty[i];
        var display;
        if(difficulty[i] >= 1 && difficulty[i] <= 33.32){
          display = "<td><font color = 'green'>"+difficulty[i]+"%</font></td>";
        }else if(difficulty[i] >= 33.33 && difficulty[i] <= 66.65){
          display = "<td><font color = 'orange'>"+difficulty[i]+"%</font></td>";
        }else if(difficulty[i] >= 66.66 && difficulty[i] <= 100.00){
          display = "<td><font color = 'red'>"+difficulty[i]+"%</font></td>";
        }else{
          display = "<td>No one took the quiz.</td>";
        }
        $("#questions_container").append("<tr><td>" + questions_array[i] + "</td>"+display+"<td><button class='btn btn-primary btn-xs' onclick = \"deleteQuiz(\""+loc+"\");\"><i class='fa fa-pencil'></i></button><button class='btn btn-danger btn-xs'><i class='fa fa-trash-o '></i></button></td></tr>");
      }
    }).then(function(){
      $("#tbl_analysis").DataTable();
    });
  });
}
function deleteQuiz(ref){
  alert(ref);
}
function GetParameterValues(param) {  
    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');  
    for (var i = 0; i < url.length; i++) {  
        var urlparam = url[i].split('=');  
        if (urlparam[0] == param) {  
            return urlparam[1];  
        }  
    }  
}
function logout(){
  firebase.auth().signOut().then(function() {
    localStorage.clear();
    window.location.replace("logout.php");
  }, function(error) {
    alert('Sign Out Error', error);
  });
}
