/*------------------------------------------------------
    Author : www.webthemez.com
    License: Commons Attribution 3.0
    http://creativecommons.org/licenses/by/3.0/
---------------------------------------------------------  */
var config = {
  apiKey: "AIzaSyD0CsnZgDBGSFBVrtZH0HRBbVQWk__txe0",
  authDomain: "ezbio-98be1.firebaseapp.com",
  databaseURL: "https://ezbio-98be1.firebaseio.com",
  storageBucket: "ezbio-98be1.appspot.com",
  messagingSenderId: "595946963410"
};
firebase.initializeApp(config);
$(document).ready(function () {
  var test = localStorage.loggedin;
      if(test != "true"){
          window.location.replace("welcomepage.php");
  }
  firebase.database().ref("subjects/" + localStorage.memberkey).orderByKey().once('value').then(function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
            $('#cmb_subjects').append("<option value = '" + childSnapshot.key + "'> " + childSnapshot.key + "</option>")
        });
    }).then(function() {
        loadSubject();
    });
  $("#cmb_subjects").on('change', function(e){
    e.preventDefault();
    $("#container_subjects").html('');
    $("#cmb_subjects").on('change', loadSubject());
  });
});
function logout(){
  firebase.auth().signOut().then(function() {
    localStorage.clear();
    window.location.replace("logout.php");
  }, function(error) {
    alert('Sign Out Error', error);
  });
}
function loadSubject() {
    var selected_subject = $('#cmb_subjects').val();
    var chap_num = 0;
    firebase.database().ref("subjects/" + localStorage.memberkey + "/" + selected_subject).orderByChild("chap_date_added").once('value').then(function(snapshot) {
        if (snapshot.numChildren() <= 2) //1 because of the subject added timestamp
            $("#container_subjects").append("<h1>No chapters on this subject.</h1><br>");
        snapshot.forEach(function(childSnapshot) {
            if (childSnapshot.key != "subj_date_added" && childSnapshot.key != "subj_description") {
                chap_num++;
                var toggle = childSnapshot.key.replace(/\s+/g, ''); //used for names of div
                var panel_title = childSnapshot.key;
                $("#container_subjects").append("<div class='panel-group'> <div class='panel panel-info'> <div class='panel-heading'> <h4 class='panel-title'> <a data-toggle='collapse' href='#" + toggle + "'>" + chap_num + ". " + childSnapshot.key + "</a> </h4> </div> <div id='" + toggle + "' class='panel-collapse collapse'> <ul class='list-group' id = list_" + toggle + "> </ul> <ul class = 'list-group'><li class = 'list-group-item'><a href = 'createquiz.php?title=" + CryptoJS.AES.encrypt(childSnapshot.key, "Secret Passphrase") +"&type=ct&subj=" + CryptoJS.AES.encrypt(selected_subject, "Secret Passphrase") + "'> + Create Quiz For This Chapter</a></li></ul> </div> </div> </div>");
                firebase.database().ref("subjects/" + localStorage.memberkey + "/" + selected_subject + "/" + childSnapshot.key).orderByChild("lesson_date_added").once('value').then(function(snapshot) {
                    var lesson_num = 0;
                    snapshot.forEach(function(childSnapshot) {
                        if (childSnapshot.key != "chap_date_added" && childSnapshot.key != "quiz") {
                            lesson_num++;
                            var hey = CryptoJS.AES.encrypt(childSnapshot.key, "Secret Passphrase");
                            var str = "subjects/" + localStorage.memberkey + "/" + selected_subject + "/"  + panel_title + "/" + childSnapshot.key;
                            var subj = CryptoJS.AES.encrypt(str, "Secret Passphrase");
                            var s = CryptoJS.AES.encrypt(selected_subject, "Secret Passphrase"); 
                            if(childSnapshot.child("quiz").exists()){
                                $("#list_" + toggle).append("<li class='list-group-item'><div class = 'row'><div class = 'col-md-6'>" + chap_num + "." + lesson_num + " " + childSnapshot.key + "</div><div class = 'col-md-6'><a href = \"itemanalysis.php?subj="+ subj +"&s=" + s + "\">Manage</a></div></div></li>");
                            }else{
                                $("#list_" + toggle).append("<li class='list-group-item'>" + chap_num + "." + lesson_num + " " + childSnapshot.key + " <a href = 'createquiz.php?title=" + hey +"&type=aq&sj=" + CryptoJS.AES.encrypt(selected_subject, "Secret Passphrase") + "&chap=" + CryptoJS.AES.encrypt(panel_title, "Secret Passphrase") + "'> + Create Quiz For This Lesson</a></li>");
                            }
                        }
                    });
                });
            }
        });
    });
}